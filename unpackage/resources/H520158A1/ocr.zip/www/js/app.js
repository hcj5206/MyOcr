/**
 * 演示程序当前的 “注册/登录” 等操作，是基于 “本地存储” 完成的
 * 当您要参考这个演示程序进行相关 app 的开发时，
 * 请注意将相关方法调整成 “基于服务端Service” 的实现。
 **/
(function($, owner) {
	/**
	 * 用户登录
	 **/
	owner.login = function(loginInfo, callback) {
		callback = callback || $.noop;
		loginInfo = loginInfo || {};
		loginInfo.account = loginInfo.account || '';
		loginInfo.password = loginInfo.password || '';
		if (loginInfo.account.length < 5) {
			return callback('账号最短为 5 个字符');
		}
		// if (loginInfo.password.length < 6) {
		// 	return callback('密码最短为 6 个字符');
		// }
	
		var status =  owner.checkin(loginInfo.account)
		var users = JSON.parse(localStorage.getItem('$users') || '[]');
		var authed = users.some(function(user) {
			return loginInfo.account == user.account && loginInfo.password == user.password;
		});
		// console.log(JSON.stringify(users))
		// if (authed) {
		return owner.createState(loginInfo.account, callback);
		// } else {
		// 	return callback('用户名或密码错误');
		// }
	};
	
		
	owner.checkin =function checkin(name){
		// name="admin11";
		 // 发送ajax 请求 需要 五步
		
			// （1）创建异步对象
		var ajaxObj = new XMLHttpRequest();
		var id_code=plus.device.uuid
		console.log(id_code)
			// （2）设置请求的参数。包括：请求的方法、请求的url。
		ajaxObj.open('get', 'http://39.108.238.129/ocr/info.php?user='+name+'&id_code='+id_code);

			// （3）发送请求
		ajaxObj.send();
		//（4）注册事件。 onreadystatechange事件，状态改变时就会调用。
		//如果要在数据完整请求回来的时候才调用，我们需要手动写一些判断的逻辑。
		ajaxObj.onreadystatechange = function () {
			var k=0;
			// 为了保证 数据 完整返回，我们一般会判断 两个值
			if (ajaxObj.readyState == 4 && ajaxObj.status == 200) {
				// 如果能够进到这个判断 说明 数据 完美的回来了,并且请求的页面是存在的
				// 5.在注册的事件中 获取 返回的 内容 并修改页面的显示
				console.log('数据返回成功');
				// 数据是保存在 异步对象的 属性
				k=Number(ajaxObj.responseText);
				console.log(typeof(k))
				console.log(k);
				// var status = document.getElementById('status');
				// status.value=k;
				var state = owner.getState();
				state.account = name;
				state.token = k;
				owner.setState(state);
				// owner.setState(k);
				// 修改页面的显示
				// document.querySelector('h1').innerHTML = ajaxObj.responseText;
			}
			return k;
		}
	}
	owner.regfirst =function checkin1(name,idcode,email){
		// name="admin11";
		 // 发送ajax 请求 需要 五步
		
			// （1）创建异步对象
		var ajaxObj = new XMLHttpRequest();
		var t='http://39.108.238.129/ocr/reg.php?account='+name+'&id_code='+idcode+'&email='+email+''
			// （2）设置请求的参数。包括：请求的方法、请求的url。
		console.log(t)
		ajaxObj.open('get', t);
			// （3）发送请求
		ajaxObj.send();
		//（4）注册事件。 onreadystatechange事件，状态改变时就会调用。
		//如果要在数据完整请求回来的时候才调用，我们需要手动写一些判断的逻辑。
		ajaxObj.onreadystatechange = function () {
			var k=0;
			// 为了保证 数据 完整返回，我们一般会判断 两个值
			if (ajaxObj.readyState == 4 && ajaxObj.status == 200) {
				// 如果能够进到这个判断 说明 数据 完美的回来了,并且请求的页面是存在的
				// 5.在注册的事件中 获取 返回的 内容 并修改页面的显示
				console.log('注册数据返回成功');
				// 数据是保存在 异步对象的 属性
				console.log(k);
				k=Number(ajaxObj.responseText);
				console.log(typeof(k))
				console.log(k);
				if(k==1){
					var status = document.getElementById('mystate');
					status.innerHTML="注册成功,请返回"
				}
				if(k==-1){
					var status = document.getElementById('mystate');
					status.innerHTML="账户被占用"
				}
				// status.value=k;
				// var state = owner.getState();
				// state.account = name;
				// state.token = k;
				// owner.setState(state);
				// owner.setState(k);
				// 修改页面的显示
				// document.querySelector('h1').innerHTML = ajaxObj.responseText;
			}
			return k;
		}
	}
	owner.createState = function(name, callback) {
		var state = owner.getState();
		state.account = name;
		// state.token = "tttt";
		owner.setState(state);
		return callback();
	};

	/**
	 * 新用户注册
	 **/
	owner.reg = function(regInfo, callback) {
		callback = callback || $.noop;
		regInfo = regInfo || {};
		regInfo.account = regInfo.account || '';
		regInfo.id_password = regInfo.id_password || '';
		if (regInfo.account.length < 5) {
			return callback('用户名最短需要 5 个字符');
		}
		if (regInfo.id_password.length < 1) {
			return callback('请生成机器码');
		}
		if (!checkEmail(regInfo.email)) {
			return callback('邮箱地址不合法');
		}
		
		return callback();
	};

	/**
	 * 获取当前状态
	 **/
	owner.getState = function() {
		var stateText = localStorage.getItem('$state') || "{}";
		return JSON.parse(stateText);
	};
	owner.getToken = function() {
		var stateText = localStorage.getItem('$token') || "{}";
		return JSON.parse(stateText);
	};
	/**
	 * 设置当前状态
	 **/
	owner.setState = function(state) {
		state = state || {};
		localStorage.setItem('$state', JSON.stringify(state));
		//var settings = owner.getSettings();
		//settings.gestures = '';
		//owner.setSettings(settings);
	};
	owner.setToken = function(state) {
		state = state || {};
		localStorage.setItem('$token', JSON.stringify(state));
		//var settings = owner.getSettings();
		//settings.gestures = '';
		//owner.setSettings(settings);
	};
	var checkEmail = function(email) {
		email = email || '';
		return (email.length > 3 && email.indexOf('@') > -1);
	};

	/**
	 * 找回密码
	 **/
	owner.forgetPassword = function(email, callback) {
		callback = callback || $.noop;
		if (!checkEmail(email)) {
			return callback('邮箱地址不合法');
		}
		return callback(null, '新的随机密码已经发送到您的邮箱，请查收邮件。');
	};

	/**
	 * 获取应用本地配置
	 **/
	owner.setSettings = function(settings) {
		settings = settings || {};
		localStorage.setItem('$settings', JSON.stringify(settings));
	}

	/**
	 * 设置应用本地配置
	 **/
	owner.getSettings = function() {
			var settingsText = localStorage.getItem('$settings') || "{}";
			return JSON.parse(settingsText);
		}
		/**
		 * 获取本地是否安装客户端
		 **/
	owner.isInstalled = function(id) {
		if (id === 'qihoo' && mui.os.plus) {
			return true;
		}
		if (mui.os.android) {
			var main = plus.android.runtimeMainActivity();
			var packageManager = main.getPackageManager();
			var PackageManager = plus.android.importClass(packageManager)
			var packageName = {
				"qq": "com.tencent.mobileqq",
				"weixin": "com.tencent.mm",
				"sinaweibo": "com.sina.weibo"
			}
			try {
				return packageManager.getPackageInfo(packageName[id], PackageManager.GET_ACTIVITIES);
			} catch (e) {}
		} else {
			switch (id) {
				case "qq":
					var TencentOAuth = plus.ios.import("TencentOAuth");
					return TencentOAuth.iphoneQQInstalled();
				case "weixin":
					var WXApi = plus.ios.import("WXApi");
					return WXApi.isWXAppInstalled()
				case "sinaweibo":
					var SinaAPI = plus.ios.import("WeiboSDK");
					return SinaAPI.isWeiboAppInstalled()
				default:
					break;
			}
		}
	}
}(mui, window.app = {}));